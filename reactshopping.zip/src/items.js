import react, { Component } from "react";
const item = [
  {
    id: 1,
    img:
      "https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcTNlSgLlq2GWkfm16w5BSOVc2aa9Qz5IMl1nQ&usqp=CAU",
    name: "shirt",
    price: 100,
    description: "This is a Shirt",
    quantity: 100,
  },
  {
    id: 2,
    img: "https://webstockreview.net/images/clipart-clothes-jeans-19.png",
    name: "pant",
    price: 200,
    description: "This is a Pant",
    quantity: 50,
  },
  {
    id: 3,
    img:
      "https://www.pinclipart.com/picdir/middle/85-859446_cap-png-mart-black-sports-hat-clipart.png",
    name: "cap",
    price: 50,
    description: "This is a Cap",
    quantity: 5,
  },
  {
    id: 4,
    img:
      "https://www.99images.com/photos/celebrities/rashmika-mandanna/rashmika-mandanna-beautiful-hd-photos-mobile-wallpapers-hd-androidiphone-xcvz.jpg?v=1578075904",
    name: "Saree",
    price: 500,
    description: "This is a Saree",
    quantity: 5,
  },
  {
    id: 5,
    img:
      "https://purepng.com/public/uploads/large/purepng.com-running-shoesrunning-shoesrunningshoessportingphysical-activitiesstyle-17015281857684savq.png",
    name: "Shoes",
    price: 400,
    description: "This is a Shoes",
    quantity: 5,
  },
];
export default item;
